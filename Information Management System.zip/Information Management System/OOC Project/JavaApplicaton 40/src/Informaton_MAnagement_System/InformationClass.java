package Informaton_MAnagement_System;


public class InformationClass {
    
    String name;
    String home_address ;
    String country ;
    String gender ;
    String degree ;

    InformationClass()
    {
      
        
        
    }
    
    
    
}

